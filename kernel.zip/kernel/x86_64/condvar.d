condvar.o: condvar.c
