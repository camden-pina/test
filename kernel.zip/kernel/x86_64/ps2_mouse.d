ps2_mouse.o: ps2_mouse.c ps2_mouse.h include/descriptor_tables/isr.h \
 include/descriptor_tables/../kernel.h include/printf.h include/kernel.h \
 include/atomics.h include/interrupts/ioapic.h include/io.h \
 include/wm/wm.h
