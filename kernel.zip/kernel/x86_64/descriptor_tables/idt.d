descriptor_tables/idt.o: descriptor_tables/idt.c \
 include/descriptor_tables/idt.h include/interrupts/ioapic.h \
 include/descriptor_tables/isr.h include/descriptor_tables/../kernel.h \
 include/printf.h include/kernel.h include/atomics.h \
 include/descriptor_tables/gdt.h include/string.h \
 include/interrupts/lapic.h include/panic.h
