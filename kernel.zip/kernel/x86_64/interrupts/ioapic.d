interrupts/ioapic.o: interrupts/ioapic.c include/interrupts/ioapic.h \
 include/interrupts/lapic.h include/acpi/tables.h include/acpi/acpi.h \
 include/kernel.h include/printf.h include/atomics.h include/string.h \
 include/io.h include/panic.h include/cpu/cpu.h
