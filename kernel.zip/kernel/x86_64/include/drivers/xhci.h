#ifndef XHCI_H
#define XHCI_H

#include <stdint.h>
#include <stdbool.h>
#include <drivers/usb.h> // usb_host_controller_t, usb_setup_packet_t

/*
 * Example interrupt flag - set it to whatever your IOAPIC or APIC code expects
 */
#define IRQ_FLAGS_LEVEL_TRIGGERED 0x01

/*
 * TRB Types
 */
#define TRB_TYPE_SETUP_STAGE         2
#define TRB_TYPE_DATA_STAGE          3
#define TRB_TYPE_STATUS_STAGE        4
#define TRB_TYPE_CMD_COMPLETION      33
#define TRB_TYPE_TRANSFER_EVENT      32
#define TRB_TYPE_PORT_STATUS_CHANGE  34
#define TRB_TYPE_NOOP 8
#define TRB_TYPE_ENABLE_SLOT         9
#define TRB_TYPE_DISABLE_SLOT        10
#define TRB_TYPE_ADDRESS_DEVICE      11

#define XHCI_CMD_RING_SIZE 64
#define TRB_TYPE_LINK      6

/*
 * Completion Codes
 */
#define XHCI_COMP_SUCCESS           1
#define XHCI_COMP_SHORT_PACKET     13

// Base offset for the xHCI Port Status and Control registers.
// (This value is hardware-specific; adjust as needed.)
#define XHCI_PORTSC_BASE 0x400

// Stride between successive port registers.
#define XHCI_PORTSC_STRIDE 0x10

// Macro to compute the offset for a given port number.
#define PORTSC_OFFSET(port) (XHCI_PORTSC_BASE + ((port) * XHCI_PORTSC_STRIDE))

// Define the bit mask indicating a connected device.
// (This mask is based on your hardware documentation; adjust as necessary.)
#define PORTSC_CONNECTED_BIT (1 << 0)

/*
 * xHCI function prototypes
 */
int init_xhci_controller(pci_device_t *pci_dev);

int xhci_control_transfer(usb_host_controller_t *hc, uint8_t dev_addr,
                          usb_setup_packet_t *setup, void *buffer, int length);

int xhci_bulk_transfer(usb_host_controller_t *hc, uint8_t dev_addr,
                       uint8_t endpoint, void *buffer, int length);

int xhci_interrupt_transfer(usb_host_controller_t *hc, uint8_t dev_addr,
                            uint8_t endpoint, void *buffer, int length);

int xhci_iso_transfer(usb_host_controller_t *hc, uint8_t dev_addr,
                      uint8_t endpoint, void *buffer, int length,
                      uint32_t frame);

#endif // XHCI_H
