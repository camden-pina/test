thread.o: thread.c
