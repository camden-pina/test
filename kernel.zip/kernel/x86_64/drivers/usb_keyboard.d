drivers/usb_keyboard.o: drivers/usb_keyboard.c \
 include/drivers/usb_keyboard.h include/drivers/usb.h \
 include/drivers/pci.h include/printf.h include/kernel.h \
 include/atomics.h
