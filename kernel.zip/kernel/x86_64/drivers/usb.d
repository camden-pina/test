drivers/usb.o: drivers/usb.c include/drivers/usb.h include/drivers/pci.h \
 include/drivers/ehci.h include/drivers/uhci.h include/drivers/uhci_td.h \
 include/printf.h include/kernel.h include/atomics.h include/panic.h \
 include/io.h include/mm/pmm.h include/queue.h include/mm_types.h \
 include/ref.h include/str.h include/string.h
