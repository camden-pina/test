errno.o: errno.c
