#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    puts("Hello from minlibc!");
    while (1) {
    }
    exit(0);
}
