#ifndef JKGH
#define JKGH

/* System call numbers */
#define SYS_exit    1
#define SYS_FORK    2
#define SYS_EXECVE  3
#define SYS_WAIT    4
#define SYS_write   5   /* for example, to write to console */


long syscall6(long n,
    long a1,long a2,long a3,
    long a4,long a5,long a6);

#endif