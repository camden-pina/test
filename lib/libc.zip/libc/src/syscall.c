#include "syscall.h"
#include <unistd.h>
#include <stddef.h>

long write(int fd, const void *buf, size_t len)
{
    return syscall6(SYS_write, fd, (long)buf, len, 0, 0, 0);
}

void _exit(int status)
{
    syscall6(SYS_exit, status, 0, 0, 0, 0, 0);
    for (;;)
        __asm__("hlt");
}
