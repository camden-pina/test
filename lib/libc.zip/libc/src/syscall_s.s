/* userlib/syscall.S  —  generic 6‑argument syscall wrapper
 *
 * SysV C calling‑convention on entry:
 *   RDI = n     (syscall number)
 *   RSI = a1    (arg1)
 *   RDX = a2    (arg2)
 *   RCX = a3    (arg3)
 *   R8  = a4    (arg4)
 *   R9  = a5    (arg5)
 *
 * We also need arg6 (a6) but the C caller had no more registers; it is
 * sitting on the stack at  +8(%rsp)  (just above the return address).
 *
 * x86‑64 SYSCALL ABI on entry to the kernel:
 *   RAX = n     RDI = a1  RSI = a2  RDX = a3  R10 = a4  R8 = a5  R9 = a6
 */

        .text
        .globl  syscall6
        .type   syscall6,@function
syscall6:
.hlt:
jmp .hlt
        /* move the arguments where the kernel expects them */
        mov     %rdi, %rax          /* n   → RAX */
        mov     %rsi, %rdi          /* a1  already in RDI, but keep symmetrical */
        mov     %rdx, %rsi          /* a2  → RSI */
        mov     %rcx, %rdx          /* a3  → RDX */
        mov     %r8,  %r10          /* a4  → R10 */
        mov     %r9,  %r8           /* a5  →  R8 */
        mov     8(%rsp), %r9        /* a6  (stack) → R9 */

        syscall                     /* enter kernel */

        ret                         /* result already in RAX */
        .size   syscall6, .-syscall6
